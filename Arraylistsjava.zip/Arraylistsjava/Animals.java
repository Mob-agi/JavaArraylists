import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.List;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Main{
public static void main(String[]args) throws IOException {
		Scanner a = new Scanner(System.in);
		System.out.println("Enter the filename with an extension .csv");
        String filename = a.nextLine();
		
	    //ArrayList<Main> Animal = new ArrayList<>();
		List<List<String>> records = new ArrayList<>();
        try (Scanner b = new Scanner(new File(filename));) {
            while (b.hasNextLine()) {
                records.add(getRecord(b.nextLine()));
            }
        }
        int menu;
        do {
            System.out.println("Select a number from 1-7 where\n"+
                    "1.Display Complete List of items in Original order\n"+
                    "2.Delete an Item after Seraching for it\n"+
                    "3.Add a new Item\n"+
                    "4.Modify an item based on a field\n"+
                    "5.Generate a Screen report\n"+
                    "6.Create updated .Csvfile with a new List of Items\n"+
                    "7.Exit");
                    menu=a.nextInt();
                        switch (menu) {
                            case 1:
                                Header();
                    	        for (int i = 0; i < records.size();i++) 
                    	        { 
                    	           List<String> Element=records.get(i);
                    	           System.out.println(Element.get(0)+"\t\t"+Element.get(1)+"\t\t"+Element.get(2)+"\t\t"+Element.get(3)); 		
                    	        } 
                                break;
                            case 2:
                                System.out.println("Enter the item(position) you wish to Delete");
                                int position=a.nextInt();
                            	records.get(position);
                            	records.remove(position);
                                Header();
                    	        for (int i = 0; i < records.size();i++) 
                    	        { 
                    	           List<String> Element=records.get(i);
                    	           System.out.println(Element.get(0)+"\t\t"+Element.get(1)+"\t\t"+Element.get(2)+"\t\t"+Element.get(3)); 		
                    	        }
                                break;
                            case 3:
                            	 List<String> list=new ArrayList<String>();  
                                 //Adding elements in the List 
                                 System.out.println("Enter the details of items in the following order");
                                 list.add(retName());  
                                 list.add(retOrigin());  
                                 list.add(retColor());  
                                 list.add(retAge()); 
                                 records.add(list);
                                Header();
                    	        for (int i = 0; i < records.size();i++) 
                    	        { 
                    	           List<String> Element=records.get(i);
                    	           System.out.println(Element.get(0)+"\t\t"+Element.get(1)+"\t\t"+Element.get(2)+"\t\t"+Element.get(3)); 		
                    	        } 
                    	        break;
                                case 4:
                                    System.out.println("Enter the item(position) you wish to change");
                                    int g=a.nextInt();
                                	System.out.println("Enter the field(position) you wish to change");
                                	int d =a.nextInt();
             
                            	    List<String> List=records.get(g);
                            	   if (d==3){
                             	        List.set(3,retAge());
                            	    }
                            	    else if (d==2){

                            	        List.set(2,retColor());
                            	    }
                            	    else if(d==0){

                            	        List.set(0,retName());
                            	    }
                            	    else if(d==1){
                            	        List.set(1,retOrigin());
                            	    }
                            	    Header();
                     	            System.out.println(List.get(0)+"\t\t"+List.get(1)+"\t\t"+List.get(2)+"\t\t"+List.get(3));
                                    break;
                                    case 5:
                                    	System.out.println("Enter the field you wish to print");
                                    	int w =a.nextInt();
                            	        for (int i = 0; i < records.size();i++) 
                            	        { 
                            	           List<String> Element=records.get(i);
                            	           System.out.println(Element.get(w)); 		
                            	        }
                            	        break;
                                    case 6:
                                            File file = new File("New Animal.csv");;
                                            FileWriter fw = new FileWriter(file);
                                            BufferedWriter bw = new BufferedWriter(fw);
                            	        for (int i = 0; i < records.size();i++) 
                            	        { 
                            	            List<String> Element=records.get(i);
                                            bw.write(Element.get(0)+","+Element.get(1)+","+Element.get(2)+","+Element.get(3));
                                            bw.newLine();
                            	        }
                                            bw.close();
                                            fw.close();
                                        break;
                            default:
                                    System.out.println("Invalid Choice");
                            break;
                        }

        }
        while(menu!=7);
}

public static void Header(){
   System.out.println("Name" +"\t\t"+"Origin"+"\t\t"+"Color"+"\t\t"+"Age"); 
}
                	        
public static String retAge(){
    System.out.println("Enter their Age");
    Scanner abc=new Scanner(System.in);
    int e=abc.nextInt();
    String f=Integer.toString(e);
    return f;
}
public static String retName(){
    System.out.println("Enter their Name");
    Scanner abc=new Scanner(System.in);
    String p =abc.nextLine();
    return p;
}
public static String retColor(){
    System.out.println("Enter their Color");
    Scanner abc=new Scanner(System.in);
    String t =abc.nextLine();
    return t;
}
public static String retOrigin(){
    System.out.println("Enter their Origin");
    Scanner abc=new Scanner(System.in);
    String y =abc.nextLine();
    return y;
}

private static List<String> getRecord(String line) {
	// TODO Auto-generated method stub
    List<String> values = new ArrayList<String>();
    try (Scanner c = new Scanner(line)) {
        c.useDelimiter(",");
        while (c.hasNext()) {
            values.add(c.next());
        }
    }
    return values;
}
}