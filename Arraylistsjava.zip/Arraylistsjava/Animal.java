
public class Animals{
	private String name;
	private String breed;
	private int age;
	// GETTER METHODS

	//getter method to return animal name
	public String getName() 
	{
		return name;
	}

	//getter method to return animal breed
	public String getBreed() 
	{
		return breed;
	}

	////getter method to return animal color
	public int getAge() 
	{
		return age;
	}
	// SETTER METHODS

		//setter method to return animal name
		public void setName(String name) 
		{
			this.name = name;
		}

		//setter method to return animal breed
		public void setBreed(String breed) 
		{
			this.breed = breed;
		}

		//setter method to return animal color
		public void setAge(int age) 
		{
			this.age = age;
		}

}